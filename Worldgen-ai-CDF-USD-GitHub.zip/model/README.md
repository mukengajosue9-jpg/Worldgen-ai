# Modèle local (à ajouter plus tard)

Ce dossier est réservé aux fichiers d'un modèle de vision entraîné et validé.

Aucun modèle n'est inclus dans ce paquet. Avant d'ajouter un modèle, il faut :
1. obtenir des images dont l'authenticité est confirmée par une source fiable ;
2. distinguer les devises (CDF/USD), valeurs et séries de billets ;
3. séparer les données d'entraînement, validation et test par source/session pour éviter les fuites ;
4. mesurer les faux positifs et faux négatifs sur des billets et photos jamais vus ;
5. tester en conditions réelles, y compris lumière, usure et qualité de caméra.

Une simple photo RGB ne permet pas de voir tous les éléments de sécurité (relief, UV, magnétisme, transparence). Le résultat doit rester une aide à la vérification, jamais une garantie.
