# Worldgen-ai — scanner CDF/USD

## Contenu
- `index.html`: interface de scanner, aperçu photo et analyse locale de luminosité/contraste.
- `model/README.md`: emplacement et exigences pour un futur modèle.
- `.github/workflows/build-apk.yml`: construction d'une APK Android depuis le site avec Capacitor.

## Important
Ce paquet **ne contient pas de modèle d'IA entraîné** et ne détecte pas encore les faux billets. L'analyse actuelle porte seulement sur la qualité de l'image. Il serait dangereux d'afficher un verdict vrai/faux sans données fiables, modèle entraîné et validation indépendante.

## Installer sur GitHub depuis un téléphone
1. Dans le dépôt, remplace `index.html` par ce fichier.
2. Remplace `.github/workflows/build-apk.yml` par le workflow fourni.
3. Commit les changements.
4. Ouvre Actions et lance `Build Worldgen-ai Android APK`.
5. Télécharge l'artefact `Worldgen-ai-APK` après réussite.

## Pour ajouter une vraie IA sur appareil
Il faudra constituer un jeu de données autorisé, étiqueté par devise, valeur et série, puis entraîner et tester un modèle de vision. Le modèle et le runtime mobile devront ensuite être empaquetés avec l'application. Ne pas utiliser des photos aléatoires comme vérité terrain.
